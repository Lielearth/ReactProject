import { Route, Routes } from 'react-router-dom'
import Footer from '../../components/Footer/Footer'
import Header from '../../components/Header/Header'
import './Default.css'
import Home from '../../pages/Home/Home'
import About from '../../pages/About/About'
import NotFound from '../../pages/NotFound/NotFound'
import SignUp from '../../pages/SignUp/SignUp'
import SignIn from '../../pages/SignIn/SignIn'
import CardPage from '../../pages/CardPage/CardPage'
import UserPage from '../../pages/UserPage/UserPage'
import AdminUser from '../../pages/AdminUser/AdminUser'
import BusinessUser from '../../pages/BusinessUser/BusinessUser'
import UserProfile from '../../pages/UserProfile/UserProfile'
import Favorites from '../../pages/Favorites/Favorites'
import CreateCard from '../../pages/CreateCard/CreateCard'
import MyCards from '../../pages/MyCards/MyCards'
import UpdateCard from '../../pages/UpdateCard/UpdateCard'




export default function Defaout() {
  return (
    <div className='Default'>
        <Header></Header>
        <Routes>
            <Route path='/Home' element={<Home/>}/>
            <Route path='About' element={<About/>}/>
            <Route path='Signup' element={<SignUp/>}/>
            <Route path='SignIn' element={<SignIn/>}/>
            <Route path='/CardPage/:cardId' element={<CardPage/>}/>
            <Route path='UserPage' element={<UserPage/>}/>
            <Route path='Admin' element={<AdminUser/>}/>
            <Route path='Business' element={<BusinessUser/>}/>
            <Route path='UserProfile' element={<UserProfile/>}/>
            <Route path='CreateCard' element={<CreateCard title={''} subtitle={''} description={''} phone={''} email={''} web={''} image={{
          url: '',
          alt: ''
        }} address={{
          state: '',
          country: '',
          city: '',
          street: '',
          houseNumber: 0,
          zip: 0
        }} _id={''}/>}/>
            <Route path='MyCards' element={<MyCards/>}/>
            <Route path='Favorites' element={<Favorites/>}/>
            <Route path='UpdateCard' element={<UpdateCard/>}/>
            <Route path='/' element={<Home/>}/>
            <Route path='*' element={<NotFound/>}/>
        </Routes>
        <Footer></Footer>
    </div>
  )
}
