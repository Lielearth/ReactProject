
import { useContext } from "react"
import { Link } from "react-router-dom"
import { AuthContext } from "../../context/AuthContext"

export default function BusinessUser() {

    const auth = useContext(AuthContext)

  return (
    <div className="BusinessUser">
        <h3>Business User Page</h3>
      <br />
        {
          (auth?.isSignedIn && (auth.isBusiness||auth.isAdmin)) ?
          <p>Welcome! you are signed in</p>
          :
          <>
          <p>You have to sign in to see this page, please sign in or sign up</p>
          <Link to="/signIn">sign-in</Link>
          <Link to="/signUp">sign-Up</Link>
          </>
        }
    </div>
  )
}
