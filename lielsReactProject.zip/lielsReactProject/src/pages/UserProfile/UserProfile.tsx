import { useContext } from "react"
import { AuthContext } from "../../context/AuthContext"


export default function UserProfile() {
  const auth = useContext(AuthContext)
  return (
    <div className="UserProfile Home">
        <h3>Profile</h3>
        <br />
        { (auth?.isSignedIn) ? 
        <>
        <img src={auth?.UserDetails?.image.url} alt={auth?.UserDetails?.image.alt} style={{width:'100px', height:'100px' }} />
        <table className="table">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Name</th>
      <td>{auth?.UserDetails?.name.first} {auth?.UserDetails?.name.last}</td>
    </tr>
    <tr>
      <th scope="row">Phone Number</th>
      <td>{auth?.UserDetails?.phone}</td>
    </tr>
    <tr>
      <th scope="row">Address</th>
      <td>{auth?.UserDetails?.address.country} {auth?.UserDetails?.address.city} 
      {auth?.UserDetails?.address.street} {auth?.UserDetails?.address.street} {auth?.UserDetails?.address.houseNumber}</td>
    </tr>
    <tr>
      <th scope="row">Created at:</th>
      <td>{auth?.UserDetails?.createdAt}</td>
    </tr>
  </tbody>
</table>
<button type="button" onClick={()=>auth.signOut()} className="btn btn-danger"> Sign-out</button>
    </>
    :
    <>
    <h4>You need to login or signup to see this page</h4>
    </>
    }
    </div>
  )
}
