import { useContext, useEffect, useState } from 'react'
import './Home.css'
import { useNavigate, useParams } from 'react-router-dom'
import { FaHeart } from "react-icons/fa";
import { AuthContext } from '../../context/AuthContext';
import { Button } from 'react-bootstrap';


interface Icard {
  _id:string
  title:string
  description:string
  image:{url:string, alt:string}
  bizNumber:number
  user_id:string
  phone:number
  address:{country:string, city:string}
  likes:[]
}

export default function Home() {
  
  const [cards, setCards] = useState<null|Icard[]>(null)
  const [error, setError] = useState<null|string>(null)
  const [likedCard, setLikedCard] = useState<Icard|null>(null)
  const auth = useContext(AuthContext)
  const {cardId} = useParams()

  const navigate = useNavigate()

  //get all the cards
  useEffect( ()=> {
  const fetchAllCards = async()=>{
    try{
      const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards`, {
        method:'GET',
        headers:{'Content-Type': 'application/json'}
      })
      const data = await response.json()  
      setCards(data)
    }catch(err){
      const errMessage = (err as Error).message
      setError(errMessage)
    }
  }
  fetchAllCards()
  }
  ,[]
  )

  const goToCardDetails = (cardId: string) => {
    navigate(`/CardPage/${cardId}`, { state: { cardId: cardId } })
  }

  const likeAcard = async(cardId:string)=>{
    try {
      const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
        method:'PATCH',
        headers:{
        'Content-Type': 'application/json',
        'x-auth-token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTNhNjA4ZDFjN2NkODBjMWZkMjc1MzIiLCJpc0J1c2luZXNzIjp0cnVlLCJpc0FkbWluIjp0cnVlLCJpYXQiOjE3MDY3ODExMDF9.Bp5E3holRYFotvF6ACHxW4sQkAftCtL6EXHHbKl9qZ4'
      },
        body:JSON.stringify(
          {
            likes: likedCard?.user_id
          }
        )
      })
      const data = await response.json()  
      setLikedCard(data)
      console.log(data);
      if(data) {
        alert('liked!')
      }
    } catch (err) {
      const errMessage = (err as Error).message
      setError(errMessage)
    }
  }


  
  return (
    <>
    <div className='Home Page'>
        <h1 className='text-danger'>BCards</h1>
        <h4>If you need a business card you've arrived to the right place!</h4>
        <p>Check out our premade business cards down below <br></br> 
        If you want to mark your favorite cards just sign up freely <br></br> 
        Sign up as business user to create your oun Business cards and edit them
        </p>
        {(error) && <p>Error getting cards! <br />{error}</p>}
        <div className='container'>
        {
          (cards)?
          cards.map((card)=>
          <div className="card" key={card._id}>
          <img src={card.image.url} className="card-img-top" alt={card.image.alt}/>
         <div className="card-body text-bg-dark">
         <h5 className="card-title">{card.title}</h5>
         <p className="card-text">{card.description}</p>
         <p className="card-text">{card.bizNumber}</p>
         <Button variant="danger" size='sm' onClick={() => goToCardDetails(card._id)}>See Details</Button>
         {
         (auth?.isSignedIn) ?
          <FaHeart onClick={()=>likeAcard(card._id)} style={{cursor:'pointer'}} />
          :
          <></>
          }
         </div>
         </div>
            )
          :
          (!error) && 'No cards'
        }
      </div>
      </div>
  </>
  )
}
