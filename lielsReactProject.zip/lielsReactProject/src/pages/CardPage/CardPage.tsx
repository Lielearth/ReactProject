import { useContext, useEffect, useState } from 'react'
import './CardPage.css'
import { useParams } from 'react-router-dom'
import { Button } from 'react-bootstrap'
import { AuthContext } from '../../context/AuthContext'
import { Link } from 'react-router-dom'


interface ICard {
  _id: string
  title: string
  subTitle: string
  description: string
  image: { url: string, alt: string }
  bizNumber: number
  user_id: string
  phone:number
  address:{
    country:string,
    city:string,
  }
}
  

export default function CardPage() {

    
  const { cardId } = useParams()

  const [card, setCard] = useState<ICard|null>(null)
  const [error, setError] = useState<string|null>(null)
  const auth = useContext(AuthContext)

  useEffect(() => {
    const fetchCard = async () => {
      try {
        const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json()
        if (!response.ok) throw new Error(data)
        setCard(data)
      } catch (err) {
        const errMessage = (err as Error).message
        setError(errMessage)
      }
    };
    fetchCard();
  },[cardId])

  const deleteCard = async ()=>{
    try {
      const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json()
        if (!response.ok) throw new Error(data)
        setCard(data)
    } catch (err) {
      const errMessage = (err as Error).message
        setError(errMessage)
    }
  }


  return (
    <div className='CardPage Home'>
        <h1>Card View</h1>
        <div>
        {
          (error) &&
            <>
              <h5>Error getting card '{cardId}' :</h5>
              <p style={{color:'red'}}>{error}</p>
            </>
        }
      </div>
        <div className='container'>
        {
          (card)?
          <div className="card">
          <img src={card.image.url} className="card-img-top" alt={card.image.alt}/>
         <div className="card-body text-bg-dark">
         <h5 className="card-title">{card.title}</h5>
         <p className="card-text">{card.description}</p>
         <p className="card-text">{card.phone}</p>
         <p className="card-text">{card.address.country}, {card.address.city}</p>
         <p className="card-text">{card.bizNumber}</p>
         {
         (auth?.isBusiness) ?
         <>
         <Link to='/UpdateCard' className='btn btn-danger'>Edit</Link>
         <Button variant='danger' onClick={()=>deleteCard()}>Delete</Button>
         </>
          :
          <></>
          }
          </div>
         </div>
          :
          'No cards'
        }
        
      </div>
      </div>
  )
}
