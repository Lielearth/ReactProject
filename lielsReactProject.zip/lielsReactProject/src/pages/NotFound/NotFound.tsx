import './NotFound.css'

export default function NotFound() {
  return (
    <div className='NotFound Page'>
        <h1>404</h1>
        <p> Sorry, We could not find the page you are looking for</p>
    </div>
  )
}
