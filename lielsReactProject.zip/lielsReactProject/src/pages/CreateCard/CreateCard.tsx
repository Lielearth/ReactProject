
import { useState } from 'react'
import './createCard.css'
import { useNavigate } from 'react-router-dom'

interface CardCreation {
  title:string,
  subtitle:string,
  description:string,
  phone:string,
  email:string,
  web:string,
  image:{
  url:string,
  alt:string,
  },
  address:{
    state:string
    country:string
    city:string
    street:string
    houseNumber:number
    zip:number
  },
  _id:string
}

export default function CreateCard(props:CardCreation) {

  const Navigate = useNavigate();
  const [title,setTitle] = useState<string>('NewCard')
  const [subtitle,setSubtitlel] = useState<string>('This is a my new created card')
  const [description,setDescription] = useState<string>('this is a business card')
  const [phone,setPhone] = useState<string>('0545475544')
  const [email,setEmail] = useState<string>('qwe@gmail.com')
  const [web,setWeb] = useState<string>('www.bing.com')
  const [url,setUrl] = useState<string>('https://th.bing.com/th?id=OIF.bPazeWFIk7HTa9ieaXlz%2bg&rs=1&pid=ImgDetMain')
  const [alt,setAlt] = useState<string>('a wonderful picture')
  const [country,setCountry] = useState<string>('Israel')
  const [city,setCity] = useState<string>('Haifa')
  const [state,setState] = useState<string>('mercaz')
  const [street,setStreet] = useState<string>('Yam')
  const [houseNumber,setHouseNumber] = useState<string>('15')
  const [zip,setZip] = useState<string>('8920435')
  const [newcardDetails,setNewCardDetails] = useState<CardCreation|undefined>(undefined)

 
  const handleSubmit = async(e:React.FormEvent)=>{
    e.preventDefault();
    if(props){
      const newCardData = {
        title:title,
        email:email,
        subtitle:subtitle,
        description: description,
        address: {
          state:state,
          country:country,
          city:city,
          street:street,
          houseNumber:houseNumber,
          zip:zip
      },
        phone:phone,
        image:{
        url:'',
        alt:'picture',
      },
      }
      const isCreated = newcardDetails
      console.log(newCardData);
      Navigate('/MyCards')
      alert('Your card created Seccessfuly')
      if(isCreated){
      }else{
        return {Error}
      }
     }
    fetchNewcard(props)
  }


  const fetchNewcard = async(props:CardCreation)=>{
    try{
      const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards', {
      method:'POST',
      headers:{'Content-Type': 'application/json',
      'x-auth-token':'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTQyNGFlOWE4ZDFlYWUxMmQzMWUzNjAiLCJpc0J1c2luZXNzIjp0cnVlLCJpc0FkbWluIjpmYWxzZSwiaWF0IjoxNjk4ODQzNDQyfQ.znXbzyxMKeNrKf3dA8jXQ5CFptM8-iXjeFtqx3XfHD0',
    },
      body:JSON.stringify(props)
    })
    const data = await response.json()

    if(response.ok){
      setNewCardDetails(data)
    }
    if(!response.ok) return data
    return {error:undefined}
    }catch(err){
      const errMessage = (err as Error).message
      return {error:errMessage}
    }
  }


  return (
    <>
    <div className="CreateCard" style={{width:'60%',}}>
        <h4>Create a Card</h4>
        <form onSubmit={handleSubmit} className="row g-2 needs-validation">
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Web</label>
    <input type="text" className="form-control" id="validationCustom01" value={web} onChange={(e)=>setWeb(e.target.value)} required/>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Pictre url</label>
    <input type="url" className="form-control" id="validationCustom01" value={url} onChange={(e)=>setUrl(e.target.value)} required/>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Alt</label>
    <input type="text" className="form-control" id="validationCustom01" value={alt} onChange={(e)=>setAlt(e.target.value)} required/>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Title</label>
    <input type="text" className="form-control" id="validationCustom01" value={title} onChange={(e)=>setTitle(e.target.value)} required/>
    <div className="valid-feedback">
      Looks good!
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom02" className="form-label">Sub Title</label>
    <input type="text" className="form-control" id="validationCustom02" value={subtitle} onChange={(e)=>setSubtitlel(e.target.value)} required/>
    <div className="valid-feedback">
      Looks good!
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustomUsername" className="form-label">Description</label>
    <div className="input-group has-validation">
      <span className="input-group-text" id="inputGroupPrepend"></span>
      <input type="text" className="form-control" id="exampleInputEmail3" value={description} onChange={(e)=>setDescription(e.target.value)} required/>
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustomUsername" className="form-label">Email</label>
    <div className="input-group has-validation">
      <span className="input-group-text" id="inputGroupPrepend">*</span>
      <input type="email" className="form-control" id="validationCustomUsername" aria-describedby="emailHelp" value={email} onChange={(e)=>setEmail(e.target.value)} required/>
      <div className="invalid-feedback">
        You must contain a valid email.
      </div>
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom05" className="form-label">Phone Number</label>
    <input type="phone" className="form-control" id="validationCustom08" value={phone} onChange={(e)=>setPhone(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid Phone Number.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">Country</label>
    <input type="text" className="form-control" id="validationCustom03" value={country} onChange={(e)=>setCountry(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">city</label>
    <input type="text" className="form-control" id="validationCustom04" value={city} onChange={(e)=>setCity(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">State</label>
    <input type="text" className="form-control" id="validationCustom05" value={state} onChange={(e)=>setState(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">Street</label>
    <input type="text" className="form-control" id="validationCustom06" value={street} onChange={(e)=>setStreet(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">HouseNumber</label>
    <input type="text" className="form-control" id="validationCustom07" value={houseNumber} onChange={(e)=>setHouseNumber(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">Zip</label>
    <input type="text" className="form-control" id="validationCustom07" value={zip} onChange={(e)=>setZip(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-12">
    <button className="btn btn-danger" type="submit">Submit</button>
  </div>
</form>
</div>
</>
  )
}
