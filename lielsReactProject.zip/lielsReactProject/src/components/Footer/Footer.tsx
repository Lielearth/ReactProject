import { useContext } from 'react'
import './Footer.css'
import { Link } from 'react-router-dom'
import { AuthContext } from '../../context/AuthContext'

export default function Footer() {

  const auth = useContext(AuthContext)

  return (
    <div className='Footer bg-dark-subtle position-fixed bottom-0 w-100 '>
    <ul className="nav nav-underline">
      <li className="nav-item">
          <Link to={'/Home'} className="nav-link text-danger" aria-current="page">Home</Link>
      </li>
      <li className="nav-item">
          <Link to={'/About'} className="nav-link text-danger">About</Link>
      </li>
      { (auth?.isSignedIn)?
        <Link to='/Favorites' className='nav-link text-danger'>Fav Cards</Link>
        :
        <></>
        }
        {
          (auth?.isSignedIn) && (auth.isBusiness) || (auth?.isAdmin) ?
          <Link to='/MyCards' className='nav-link text-danger'>My Cards</Link>
          :
          <></>
        }
      <li className="nav-item">
          <Link to={'/'} className="nav-link text-danger" aria-current="page">Copyright © BCards, 2024</Link>
      </li>
    </ul>
  </div>
    
  )
}
